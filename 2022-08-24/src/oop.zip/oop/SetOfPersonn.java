package oop;

import java.util.Arrays;

public class SetOfPersonn {

	Person[][] persons = new Person[10][10];
	int x = 0, y = 0;

	public boolean addPerson(Person p) {
		if (contains(p)){
		return false;
		}
		persons[x][y] = p;
		if (x < 9) {
			if (y < 9) {
				y++;
			} else {
				y = 0;
				x++;
			}
		}return true;
	}
	
	public boolean contains(Person p) {	
	for (int i = 0; i < persons.length; i++) {
		for (int k = 0; k < persons[i].length; k++) {
			if (persons[i][k].equals(p)) {
				return true;
			}
		}
	}return false;
	}
	
	public int findById (int id) {
		boolean found= true;
		for (int i = 0; i < persons.length; i++) {
			for (int k = 0; k < persons[i].length; k++) {
		if (id!=persons[i][k].getId());
		found = false;
	}
}
	if(found = false) {
			System.out.println("null");
		}else {
		}
	return id;

	}

	@Override
	public String toString() {
		return "SetOfPersonn [persons=" + Arrays.toString(persons) + "]";
	}


	
	
	}
