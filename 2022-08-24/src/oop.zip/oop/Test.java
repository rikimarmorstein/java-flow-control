package oop;

public class Test {

	public static void main(String[] args) {




		SetOfPersonn set = new SetOfPersonn();
		Person p=new Person(564,"jh",45);
		set.addPerson(p);
		System.out.println(set.contains(p));
		


	}

}
